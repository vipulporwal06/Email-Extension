// // popup.js

 var myLink= document.getElementById("sendEmailButton");
 console.log(myLink);

document.addEventListener('DOMContentLoaded',  () => {
  var sendEmailButton = document.getElementById('sendEmailButton');
  console.log(chrome.identity);
  sendEmailButton.addEventListener('click', () => {
    chrome.identity.getAuthToken({ interactive: true }, function (token) {
      console.log(token);
      if (!chrome.runtime.lastError) {
        sendEmail(token);
      }
    });
  });
});

function sendEmail(token) {
  var emailContent = "Hello, this is the email content!";
  var subject = "Subject of the email";

  fetch('https://www.googleapis.com/gmail/v1/users/me/messages/send', {
  method: 'POST',
    async: true,
    headers: {
      'Authorization': 'Bearer ' + token,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      raw: btoa(
        'To: pradeep@dotvik.com\n' +
        'Subject: ' + subject + '\n\n' +
        emailContent
      )
    }),
  })
    .then(response => response.json())
    .then(data => console.log('Email sent:', data))
    .catch(error => console.error('Error sending email:', error));
}

