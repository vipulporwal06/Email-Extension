// content.js

// Code to get email content from the webpage

// chrome.runtime.sendMessage({ action: "sendEmail" });