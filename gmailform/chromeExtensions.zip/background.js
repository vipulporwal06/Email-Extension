// background.js

// chrome.action.onClicked.addListener(function(tab) {
//   chrome.tabs.executeScript(tab.id, { file: "content.js" });
// });

// chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
//   if (request.action === "sendEmail") {
//    // Replace the following code with your actual email sending logic
//    var emailContent = "Hello, this is the email content!";
//    var subject = "Subject of the email";

//    // Use the chrome.runtime.sendNativeMessage API or any other email sending method
//    // Here, we are just logging the email content to the console
//    console.log("Email Content:", emailContent);
//    console.log("Subject:", subject);

//    // You can also open a new tab to compose an email using a webmail service
//    // For example, open Gmail compose window
//    chrome.tabs.create({ url: "https://mail.google.com/mail/*" + 
//    encodeURIComponent(subject) + "&body=" + encodeURIComponent(emailContent) });

//    // You can replace the above code with the method you prefer for sending emails
//   }
// });


